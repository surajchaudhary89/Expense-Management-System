from email.policy import default
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
import streamlit as st
import requests
import pandas as pd
import plotly.express as px
from log_utils.logger import get_logger


logger = get_logger("streamlit_app")

API_URL = "http://localhost:8000"

st.set_page_config(page_title="Expense Manager", layout="centered", page_icon="💵")
st.title("💰 Expense Management System")

# Create Tabs
tab1, tab2, tab3, tab4, tab5 = st.tabs(["📂 Add/View Categories", "💸 Add Expenses",
                                        "📃 View all expenses", "🛠️ Delete Expense", "📊 Analytics"])

# Tab 1: Category
with tab1:
    st.write("Add Category Here")

    # Add Category Form
    with st.form("add_category_form"):
        cat_name = st.text_input("Enter Category Name")
        submitted = st.form_submit_button("Add Category")

        if submitted and cat_name:
            logger.info(f"Adding Category {cat_name}")
            try:
                response = requests.post(f"{API_URL}/categories", json={"name": cat_name})
                if response.status_code == 200:
                    logger.info(f"{cat_name} added successfully")
                    st.success(f"✅ Category '{cat_name}' added successfully!")
                else:
                    logger.error(f"Failed to add category '{cat_name}'")
                    st.error(f"⚠️ {response.json()['detail']}")
            except Exception as e:
                logger.exception(f"Exeption while adding '{cat_name}'")
                st.error(f"❌ Failed to connect to API: {e}")

    # View all categories
    st.text("")
    st.write("📋 Existing Categories")
    try:
        response = requests.get(f"{API_URL}/categories")
        if response.status_code == 200:
            categories = response.json()
            if categories:
                df = pd.DataFrame(categories, columns=["Category"])
                st.dataframe(df, use_container_width=True)
            else:
                st.info("No categories found.")
        else:
            st.error("Failed to fetch categories.")

    except Exception as e:
        st.error(f"❌ API error: {e}")


# ----------- Tab 2: Expenses -----------
with tab2:
    # Fetch categories for dropdown
    try:
        response = requests.get(f"{API_URL}/categories/ids")
        category_data = response.json()
        if isinstance(category_data, list):
            category_name_to_id = {cat['name']: cat['id'] for cat in category_data}
            category_names = list(category_name_to_id.keys())
        else:
            st.error("⚠️ Failed to fetch categories.")
            category_name_to_id = {}
            category_list = []
    except Exception as e:
        st.error(f"Error fetching categories: {e}")
        category_name_to_id = {}
        category_list = []

    # Form to Add Expense
    st.subheader("➕ Add Your Expense Here...")

    with st.form("add_expense_form"):
        col1, col2 = st.columns(2)
        with col1:
            date = st.date_input("Date")
            amount = st.number_input("Amount (₹)", min_value=1.0, step=1.0)
        with col2:
            category = st.selectbox("Category", category_names)
            description = st.text_input("Description")

        submit_expense = st.form_submit_button("Add Expense")

        if submit_expense:
            logger.info(f"Adding expense: Date={date}, Amount={amount}, Category='{category}', Description='{description}'")
            payload = {
                "date": str(date),
                "amount": amount,
                "category_id": category_name_to_id[category],
                "description": description
            }
            try:
                res = requests.post(f"{API_URL}/expenses", json=payload)
                if res.status_code == 200:
                    logger.info(f"Expense added successfully!")
                    st.info("✅ Expense added successfully!")
                else:
                    logger.error(f"Failed to add expense: {res.json()['detail']}")
                    st.error("❌ Failed to add expense.")
            except Exception as e:
                logger.exception(f"Exception while adding expense: {e}")
                st.error(f"API error: {e}")



# ----------- Tab 3: View All Expenses -----------
with tab3:
    st.subheader("📃 All Expenses Here...")
    try:
        res = requests.get(f"{API_URL}/expenses")
        if res.status_code == 200:
            data = res.json()
            if data:
                df = pd.DataFrame(data)
                df.rename(columns={
                    "id": "Expense ID",
                    "date": "Date",
                    "amount": "Amount (₹)",
                    "category": "Category",
                    "description": "Description"
                }, inplace=True)
                df.set_index("Date", inplace=True)
                st.dataframe(df, use_container_width=True)
            else:
                st.info("No expenses to show yet.")
        else:
            st.warning("⚠️ Failed to fetch expenses.")
    except Exception as e:
        st.error(f"API Error: {e}")

# ----------- Tab 4: Delete Expenses -----------
with tab4:
    st.header("🗑️ Delete Expenses by Date")
    st.info("Select a date, check expenses to delete, and click the button below.")

    selected_date = st.date_input("📅 Choose a date")

    if selected_date:
        logger.info(f"User selected expenses for date: {selected_date}")
        response = requests.get(f"{API_URL}/expenses/{selected_date}")

        if response.status_code == 200:
            expenses = response.json()

            if expenses:
                st.success(f"{len(expenses)} expenses found for {selected_date}")
                logger.info(f"Found {len(expenses)} expenses")

                # Prepare data with checkbox column
                for exp in expenses:
                    exp["Select"] = False

                # Show in editable table
                df = pd.DataFrame(expenses)
                edited_df = st.data_editor(
                    df[["Select", "date", "category", "amount", "description"]],
                    key="delete_editor",
                    use_container_width=True,
                    hide_index=True
                )

                # Get selected expense IDs
                to_delete_ids = df.loc[edited_df["Select"] == True, "id"].tolist()

                if to_delete_ids:
                    if st.button("❌ Delete Selected Expenses"):
                        failed = []
                        for exp_id in to_delete_ids:
                            logger.info(f"Deleting expense {exp_id}")
                            del_response = requests.delete(f"{API_URL}/expenses/{exp_id}")
                            if del_response.status_code != 200:
                                failed.append(exp_id)

                        if not failed:
                            logger.info(f"Successfully deleted expense {exp_id}")
                            st.success("✅ Selected expenses deleted successfully! Please refresh.")
                        else:
                            logger.warning(f"Failed to delete expense {exp_id}")
                            st.error(f"❌ Failed to delete some expenses: {failed}")
                else:
                    st.info("✔️ Select one or more expenses to delete.")
            else:
                st.warning("No expenses found for this date.")
        else:
            logger.error("Failed to fetch expenses: {response.status_code}")
            st.error("Failed to fetch expenses from API.")

# ----------- Tab 5: Analytics -----------
with tab5:
    st.header("📊 Expense Analytics")
    st.text("")
    # Fetch summary from backend
    response = requests.get(f"{API_URL}/summary")
    if response.status_code != 200:
        logger.error(f"Failed to fetch, API Error: {response.status_code}")
        st.error("Failed to fetch analytics data.")
    else:
        logger.info(f"Successfully fetched expense analytics data")
        summary = response.json()

        if not summary:
            st.info("No expense data available for analytics.")
        else:
            # Process data
            df = pd.DataFrame(summary)

            # Donut Pie Chart
            st.subheader("📌 Expense Breakdown by Category (Pie Chart)")
            fig_pie = px.pie(
                df,
                names="category",
                values="total",
                hole=0.35,
                color_discrete_sequence=px.colors.sequential.RdBu,
                title="Expenses by Category"
            )
            fig_pie.update_traces(textinfo="percent+label")
            st.plotly_chart(fig_pie, use_container_width=True)

            # Bar Chart
            st.subheader("📊 Category-wise Expense (Bar Chart)")
            fig_bar = px.bar(
                df,
                x="category",
                y="total",
                color="category",
                text_auto=".2s",
                labels={"total": "Total ₹ Spent", "category": "Category"},
                title="Total Expenses by Category"
            )
            st.plotly_chart(fig_bar, use_container_width=True)

