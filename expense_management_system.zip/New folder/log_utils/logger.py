import logging
import os
from datetime import datetime

os.makedirs("logs", exist_ok=True)

log_filename = datetime.now().strftime("logs/log_%Y-%m-%d.log")


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(name)s | %(message)s",
    handlers=[
        logging.FileHandler(log_filename),
        logging.StreamHandler()
    ]
)

def get_logger(name: str) -> logging.Logger:
    return logging.getLogger(name)
