from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List
import backend.database as db
from log_utils.logger import get_logger
logger = get_logger("api")

app = FastAPI(title="Expense Management API")

#Pydantic Schemas
class Category(BaseModel):
    name: str

class Expense(BaseModel):
    date: str
    amount: float
    category_id: int
    description: str

@app.post("/categories")
def create_category(category: Category):
    logger.info(f"POST /categories called with: {category.name}")
    success = db.add_category(category.name)
    if success:
        logger.info(f"POST /categories added: {category.name}")
        return {"message": f"Category '{category.name}' added successfully."}
    else:
        logger.warning(f"POST /categories already exists or failed: {category.name}")
        raise HTTPException(status_code=400, detail="Category already exists or could not be added.")

@app.get("/categories", response_model=List[str])
def get_categories():
    logger.info(f"GET /categories called")
    return db.get_all_categories()

@app.get("/categories/ids")
def get_categories_ids():
    logger.info(f"GET /categories/ids called")
    return db.get_all_categories_with_id()

@app.post("/expenses")
def create_expense(expense: Expense):
    logger.info(f"POST /expenses called")
    expense_id = db.add_expense(expense.date, expense.amount, expense.category_id, expense.description)
    if expense_id:
        logger.info(f"POST /expenses added successfully")
        return {"expense_id": expense_id, "message": "Expense with ID {expense_id} added successfully."}
    else:
        logger.warning(f"POST /expenses already exists or failed")
        raise HTTPException(status_code=500, detail="Could not add expense.")

@app.get("/expenses")
def read_expenses():
    logger.info(f"GET /expenses called")
    return db.get_all_expenses()

@app.get("/expenses/{date}")
def read_expenses_by_date(date: str):
    logger.info(f"GET /expenses/{date} called for date: {date}")
    return db.get_expense_by_date(date)

@app.delete("/expenses/{expense_id}")
def delete_expense(expense_id: int):
    logger.info(f"DELETE /expenses/{expense_id} called")
    success = db.delete_expense_by_id(expense_id)
    if success:
        logger.info(f"DELETE /expenses/{expense_id} deleted successfully")
        return {"message": "Expense deleted successfully."}
    else:
        logger.warning(f"DELETE /expenses/{expense_id} does not exist")
        raise HTTPException(status_code=404, detail="Expense not found.")

@app.get("/summary")
def expense_summary():
    logger.info(f"GET /summary called")
    return db.get_expense_summary_by_category()






