import mysql.connector
from mysql.connector import Error
from log_utils.logger import get_logger
logger = get_logger("database")

def create_connection():
    try:
        connection = mysql.connector.connect(
            host="localhost",
            port=3306,
            user="root",
            password="root",
            database = "expense_db"
        )
        if connection.is_connected():
            return connection
    except Error as e:
        logger.warning(f"Error while connecting to MySQL: {e}")
        return None

def add_category(name: str):
    connection = create_connection()
    if connection is None:
        return False
    cursor = None
    logger.info(f"Attempting to add category: {name}")
    try:
        cursor = connection.cursor()
        query = "INSERT INTO categories (name) VALUES (%s)"
        cursor.execute(query, (name,))
        connection.commit()
        logger.info(f"✅ Category '{name}' added successfully!")
        return True
    except mysql.connector.IntegrityError:
        logger.warning(f"⚠️ Category '{name}' already exists.")
        return False
    except mysql.connector.Error as e:
        logger.error(f"❌ Failed to add category: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def get_all_categories():
    connection = create_connection()
    if connection is None:
        return []
    cursor = None
    logger.info(f"Attempting to get all categories!")
    try:
        cursor = connection.cursor()
        query = "SELECT name FROM categories"
        cursor.execute(query)
        rows = cursor.fetchall()
        categories = [row[0] for row in rows]
        logger.info(f"Retrieved {len(categories)} categories.")
        return categories

    except mysql.connector.Error as e:
        logger.error(f"❌ Failed to fetch categories: {e}")
        return []
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def get_all_categories_with_id():
    connection = create_connection()
    if connection is None:
        return []
    cursor = None
    logger.info(f"Attempting to get all categories with ids!")
    try:
        cursor = connection.cursor(dictionary=True)
        query = "SELECT name, id FROM categories"
        cursor.execute(query)
        rows = cursor.fetchall()
        logger.info(f"Retrieved {len(rows)} categories with ids.")
        return rows
    except mysql.connector.Error as e:
        logger.error(f"❌ Failed to fetch categories: {e}")
        return []
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


def add_expense(date: str, amount: float, category_id: int, description: str):
    connection = create_connection()
    if connection is None:
        return False
    cursor = None
    logger.info(f"Adding expense!")
    try:
        cursor = connection.cursor()
        query = """INSERT INTO expenses (date, amount, category_id, description)
                VALUES (%s, %s, %s, %s)"""
        values = (date, amount, category_id, description)
        cursor.execute(query, values)
        connection.commit()
        expense_id = cursor.lastrowid
        logger.info("✅ Expense added successfully!")
        return expense_id

    except mysql.connector.Error as e:
        logger.error(f"❌ Failed to add expense: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def get_all_expenses():
    connection = create_connection()
    if connection is None:
        return []
    cursor = None
    logger.info(f"Attempting to get all expenses!")
    try:
        cursor = connection.cursor(dictionary=True)
        query = """ SELECT e.id, e.date, e.amount, c.name as category, e.description 
                    FROM expenses e JOIN categories c 
                    ON e.category_id = c.id ORDER BY e.date """
        cursor.execute(query)
        expenses = cursor.fetchall()
        logger.info(f"Retrieved {len(expenses)} expenses.")
        return expenses
    except mysql.connector.Error as e:
        logger.error(f"❌ Failed to fetch expenses: {e}")
        return []
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


def get_expense_by_date(date: str):
    connection = create_connection()
    if connection is None:
        return []
    cursor = None
    logger.info(f"Attempting to get expense by date!")
    try:
        cursor = connection.cursor(dictionary=True)
        query = """ SELECT e.id, e.date, e.amount, c.name as category, e.description 
                    FROM expenses e JOIN categories c 
                    ON e.category_id = c.id
                    WHERE date = %s """
        cursor.execute(query, (date,))
        expenses = cursor.fetchall()
        logger.info(f"Retrieved {len(expenses)} expenses.")
        return expenses
    except mysql.connector.Error as e:
        logger.error(f"Failed to fetch expenses: {e}")
        return []
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def delete_expense_by_id(expense_id: int):
    connection = create_connection()
    if connection is None:
        return False
    cursor = None
    logger.info(f"Attempting to delete expense by id!")
    try:
        cursor = connection.cursor()
        query = "DELETE FROM expenses WHERE id = %s"
        cursor.execute(query, (expense_id,))
        connection.commit()
        logger.info("Expense deleted successfully!")
        return True
    except mysql.connector.Error as e:
        logger.error(f"Failed to delete expense for expense_Id: {e}")
        return False
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()

def get_expense_summary_by_category():
    connection = create_connection()
    if connection is None:
        return []
    cursor = None
    logger.info(f"Attempting to get expense summary by category!")
    try:
        cursor = connection.cursor(dictionary=True)
        query = """
            SELECT c.name AS category, SUM(e.amount) AS total
            FROM expenses e
            JOIN categories c ON e.category_id = c.id
            GROUP BY c.name
            ORDER BY total DESC
        """
        cursor.execute(query)
        summary = cursor.fetchall()
        logger.info(f"Retrieved summary of expense categories.")
        return summary
    except mysql.connector.Error as e:
        logger.error(f"❌ Failed to fetch expense summary: {e}")
        return []
    finally:
        if cursor:
            cursor.close()
        if connection:
            connection.close()


