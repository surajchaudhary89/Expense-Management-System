import pytest
from fastapi.testclient import TestClient
from backend.api import app

client = TestClient(app)

def test_read_all_categories():
    response = client.get("/categories")
    assert response.status_code == 200
    assert isinstance(response.json(), list)

def test_add_category():
    payload = {"name": "TestCategory"}
    response = client.post("/categories", json=payload)
    assert response.status_code in [200, 400]
    data = response.json()
    assert "message" in data or "detail" in data

def test_add_expense():
    payload = {
        "date": "2025-06-15",
        "amount": 123.45,
        "category_id": 1,
        "description": "Test expense"
    }
    response = client.post("/expenses", json=payload)
    assert response.status_code == 200 or response.status_code == 400
    data = response.json()
    assert "message" in data or "detail" in data


def test_get_all_expenses():
    response = client.get("/expenses")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


def test_get_expenses_by_date():
    test_date = "2025-06-15"
    response = client.get(f"/expenses/{test_date}")
    assert response.status_code == 200
    assert isinstance(response.json(), list)


def test_delete_expense():
    payload = {
        "date": "2025-06-15",
        "amount": 99.99,
        "category_id": 1,
        "description": "Delete Me"
    }
    post_resp = client.post("/expenses", json=payload)
    assert post_resp.status_code == 200
    expense_id = post_resp.json()["expense_id"]

    del_resp = client.delete(f"/expenses/{expense_id}")
    assert del_resp.status_code == 200
    assert "message" in del_resp.json()

