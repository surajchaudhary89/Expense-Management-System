import pytest
import backend.database as db
from datetime import date

def test_add_category():
    name = "TestCategory"
    result = db.add_category(name)
    assert result is True or result is False

def test_get_all_categories():
    categories = db.get_all_categories()
    assert isinstance(categories, list)
    assert "TestCategory" in categories

def test_add_expense():
    today = str(date.today())
    result = db.add_expense(date= today, amount=100.0, category_id=1, description="Test Expense" )
    assert result is True

def test_get_expense():
    expenses = db.get_all_expenses()
    assert isinstance(expenses, list)
    assert len(expenses) > 0

def test_get_expense_by_date():
    today = str(date.today())
    result = db.get_expense_by_date(date=today)
    assert isinstance(result, list)

def test_delete_expense():
    all_expenses = db.get_all_expenses()
    if all_expenses:
        last_expense = all_expenses[-1]
        expense_id = last_expense["id"]
        result = db.delete_expense_by_id(expense_id)
        assert result is True


